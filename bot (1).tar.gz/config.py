
apikey = "YOUR API KEY"
token = "YOUR BOT TOKEN"
model = "DIMOD1"
prefix = "d!"
