from discord.ext import commands
import discord
import aiohttp
import time
import json

with open(f"config.json", "r") as f:
    config=json.load(f)

prefix = config['prefix']
token = config['token']
model = config["model"]
apikey = config["apikey"]
    
bot = commands.Bot(command_prefix=prefix, intents=discord.Intents.all())

def cutter2(text, start):
    stop_word = start
    stop_condition_words = ['and', "!reason:"]
    words = text.split()
    result = []
    stop_detected = False
    w = str(stop_word).replace("[","").replace("'","").replace(",","").replace("]","").lower()

    for word in words:
        if word.lower() == w:
            stop_detected = True
        elif stop_detected:
            if word.lower() in stop_condition_words:
                break
            else:
                result.append(word)

    return ' '.join(result)

@bot.event
async def on_message(message):
    if message.author.bot:
        return
    else:
        request_headers = {
            'Authorization': 'test'
        }
        async with aiohttp.ClientSession() as session:
            api_url = 'http://us3.techstar.host:55565/request'
            global model
            request_data = {
                'message': message.content,
                'model': model
            }
            async with session.post(api_url, json=request_data, headers=request_headers) as response:
                api_response = await response.json()

        hh = api_response['response']
        
        h = json.loads(hh.replace("'", '"'))
        
        if h["detect"].startswith("True"):
            wor = cutter2(h['detect'], "True")
            await message.delete()
            r1 = cutter2(h['detect'], "!reason:")
            
            if "and" in h['detect'].split():
                r2 = cutter2(h['detect'], "and")
                
            else:
                r2 = None
            em = discord.Embed(title="Warning", color=discord.Color.red())
            if h["triggers"]["upercases"] == "true":
                co = h["count"]
                em.add_field(name="Maximum uppercase letters reached", value=f"{co}%")
            if h["triggers"]["badwords"] != "None":
                em.add_field(name="Bad word detected", value=f"Word: {wor}")
            em.set_footer(text=f"{message.author.name}")
            msg = await message.channel.send(embed=em)
            time.sleep(5)
            await msg.delete()
            
bot.run('MTE2NTY1MjY0NzcxNDQ5MjUwNw.GmcoyX.L_iawPF-skVoxQIEmO4S354yjjNE43MNHsdxF4')